""" 
faca um programa que leia o nome de 5 pessoas e armazene emuma lista de nomes. No final imprima na tela uma mensagem de boas vindas para cada nome armazenado. 
EX:
nomes=[Turing, Ada, Linus, Dijkastra, Berners-lee]
Seja bem vindo(a) tirung
Seja bem vindo(a) Ada 
Seja bem vindo(a) Linus
Seja bem vindo(a) Dijkastra
Seja bem vindo(a) Berners-lee
"""

nomes =[]
total_nomes = 5

for i in range(total_nomes):
    tmp = input(f"Digite o {i+1}° nome: ")
    nomes.append(tmp)    
#print(nomes)

print("="*15)
for j in range(len(nomes)):
    print(f" Seja Bem-vindo(a) {nomes[j].upper()}")