# Armazenar as notas de 3 alunos em uma lista. A
# Nota de cada aluno sera informada pelo teclado.

#notas = []
#tmp = float(input("nota 1: "))
#notas.append(tmp)
#notas.append(float(input("nota 2:")))
#tmp = float(input("nota 3: "))
#notas.append(tmp)
#print(notas)

n_aluno = 10
notas = []
for i in range(n_aluno):
    nota = float(input('Digite a nota: '))
    notas.append(nota)
    print(notas)




#soma = 0
#for indice in range(len(notas)):
#    soma = soma + notas[indice]
#    print(f"soma parcial {soma}")
# ###
# sum - soma dos valores presentes na lista 
# len - a quantidade de valores presente na lista

media = sum(notas)/len(notas)
print(f'media final: {media}')