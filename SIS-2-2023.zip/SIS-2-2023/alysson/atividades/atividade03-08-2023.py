""" 
Crie duas lista em python, uma para armazenar o nome e outra lista para armarzenar a idade de 5 pessoas. Posteriormente indique quais pessoas tem 18 anos ou mais e quantas pessoas so maiores de idade,
Ex:
jose, 10 anos 
Joaquin, 19 anos
Jailton, 30 anos
Juarez, 5 anos 
Joao, 18 anos
--> são maiores de idade: Joaquin, Jailton, joao
--> sao menores de idade: jose, juarez
"""

nomes = []
idade = []
total_idade = 5
total_nomes= 5

for i in range(total_nomes):
    nomes.append = input(f'Digite seu nome: ')
    tmp = int(input(f'Digite a idade {nomes[i]} '))
    idade.append(tmp)
    
maiores = "--> sao maiore de idade: "
menores = "--> sao menores de idade: "

for j in range(len(idade)):
    if idade[j]>=18:
        tmp = nomes[j]
        maiores = maiores + tmp + ","
    else:
        tmp = nomes[j]
        menores = menores + tmp + ","
        
print("----------------------------")
print(maiores)
print(menores)