numeros = [1,6,9,16,25]
print(numeros[1]) # me retorna o valor 2
print(numeros)
#consultar o ultimo elemento
print(numeros[-1])
#outra forma 
print(numeros[len(numeros)-1])

#uniao de lista 
outra_lista = [36,49,64]
nova_lista = numeros + outra_lista
print(nova_lista) 

# adicionar novos elementos na lista 
nova_lista.append(9*9)
print(nova_lista)

#corrigir o elementa da posisao
nova_lista[1] = 2**2
print(nova_lista)

#  trazer o indice e volor
for indice in range(len(nova_lista)):
    valor = nova_lista[indice]
    print(f'indice = {indice} e valor = {valor}') 
    
# outra maneira 
